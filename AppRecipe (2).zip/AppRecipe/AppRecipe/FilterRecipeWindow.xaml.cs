﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace AppRecipeWPF
{
    public partial class FilterRecipesWindow : Window
    {
        private RecipeBook recipeBook;

        public FilterRecipesWindow(RecipeBook recipeBook)
        {
            InitializeComponent();
            this.recipeBook = recipeBook;
        }

        private void FilterRecipes_Click(object sender, RoutedEventArgs e)
        {
            string ingredient = IngredientTextBox.Text.ToLower();
            string foodGroup = (FoodGroupComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            int.TryParse(MaxCaloriesTextBox.Text, out int maxCalories);

            var filteredRecipes = recipeBook.Recipes.Where(r =>
                (string.IsNullOrEmpty(ingredient) || r.Ingredients.Any(i => i.Name.ToLower().Contains(ingredient))) &&
                (string.IsNullOrEmpty(foodGroup) || r.Ingredients.Any(i => i.FoodGroup.Equals(foodGroup, StringComparison.OrdinalIgnoreCase))) &&
                (maxCalories == 0 || r.Ingredients.Sum(i => i.Calories) <= maxCalories)
            ).ToList();

            FilteredRecipeListBox.Items.Clear();
            foreach (var recipe in filteredRecipes)
            {
                FilteredRecipeListBox.Items.Add(recipe.Name);
            }
        }
    }
}
