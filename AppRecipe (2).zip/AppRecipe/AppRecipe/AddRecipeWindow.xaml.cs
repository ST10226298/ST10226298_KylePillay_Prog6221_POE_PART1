﻿using System;
using System.Windows;

namespace AppRecipeWPF
{
    public partial class AddRecipeWindow : Window
    {
        private RecipeBook recipeBook;

        public AddRecipeWindow(RecipeBook recipeBook)
        {
            InitializeComponent();
            this.recipeBook = recipeBook;
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            var recipeName = RecipeNameTextBox.Text;
            int.TryParse(NumIngredientsTextBox.Text, out int numIngredients);
            int.TryParse(NumStepsTextBox.Text, out int numSteps);

            Recipe recipe = new Recipe(recipeName);

            // Add ingredients and steps (implement dialog to add each ingredient and step)
            for (int i = 0; i < numIngredients; i++)
            {
                // Example input, replace with actual UI dialogs
                var ingredient = new Ingredient("Ingredient" + (i + 1), 1, "unit", 100, "Carbohydrates");
                recipe.AddIngredient(ingredient);
            }

            for (int i = 0; i < numSteps; i++)
            {
                var step = new Steps("Step " + (i + 1));
                recipe.AddStep(step);
            }

            recipeBook.AddRecipe(recipe);
            MessageBox.Show("Recipe added successfully!");
            this.Close();
        }
    }
}
