﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AppRecipeWPF
{
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; } = new List<Ingredient>();
        public List<Steps> Steps { get; set; } = new List<Steps>();

        public event Action<string> CaloriesExceeded;

        public Recipe(string name)
        {
            Name = name;
        }

        public void AddIngredient(Ingredient ingredient)
        {
            Ingredients.Add(ingredient);
        }

        public void AddStep(Steps step)
        {
            Steps.Add(step);
        }

        public void Scale(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        public void Reset()
        {
            Ingredients.Clear();
            Steps.Clear();
        }

        public void Display()
        {
            Console.WriteLine($"Recipe: {Name}");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in Ingredients)
            {
                Console.WriteLine($"{ingredient.Name}, {ingredient.Quantity} {ingredient.Unit}, {ingredient.Calories} calories, {ingredient.FoodGroup}");
            }
            Console.WriteLine("Steps:");
            foreach (var step in Steps)
            {
                Console.WriteLine(step.Description);
            }
        }
    }
}
