﻿namespace AppRecipeWPF
{
    public class Steps
    {
        public string Description { get; set; }

        public Steps(string description)
        {
            Description = description;
        }
    }
}
