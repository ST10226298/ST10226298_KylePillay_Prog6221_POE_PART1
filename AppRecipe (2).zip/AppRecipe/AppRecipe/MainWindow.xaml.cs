﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace AppRecipeWPF
{
    public partial class MainWindow : Window
    {
        private RecipeBook recipeBook;

        public MainWindow()
        {
            InitializeComponent();
            recipeBook = new RecipeBook();
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            // Open a new window or dialog to add a recipe
            AddRecipeWindow addRecipeWindow = new AddRecipeWindow(recipeBook);
            addRecipeWindow.Show();
        }

        private void DisplayAllRecipes_Click(object sender, RoutedEventArgs e)
        {
            RecipeListBox.Items.Clear();
            var recipes = recipeBook.Recipes.OrderBy(r => r.Name).ToList();
            foreach (var recipe in recipes)
            {
                RecipeListBox.Items.Add(recipe.Name);
            }
        }

        private void FilterRecipes_Click(object sender, RoutedEventArgs e)
        {
            // Open a new window or dialog to filter recipes
            FilterRecipesWindow filterRecipesWindow = new FilterRecipesWindow(recipeBook);
            filterRecipesWindow.Show();
        }
    }
}
