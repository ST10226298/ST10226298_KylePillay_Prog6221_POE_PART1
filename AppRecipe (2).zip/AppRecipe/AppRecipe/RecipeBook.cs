﻿using System.Collections.Generic;
using System.Linq;

namespace AppRecipeWPF
{
    public class RecipeBook
    {
        public List<Recipe> Recipes { get; set; } = new List<Recipe>();

        public void AddRecipe(Recipe recipe)
        {
            Recipes.Add(recipe);
        }

        public List<Recipe> GetRecipes()
        {
            return Recipes.OrderBy(r => r.Name).ToList();
        }

        public Recipe GetRecipeByName(string name)
        {
            return Recipes.FirstOrDefault(r => r.Name.Equals(name, System.StringComparison.OrdinalIgnoreCase));
        }

        public void ClearRecipes()
        {
            Recipes.Clear();
        }
    }
}
