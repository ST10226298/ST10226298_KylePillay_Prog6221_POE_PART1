#ST10226298 Prog Part2

## I have  cganegd the layout to make it better. I hae added more commits therefore making the program more comprehensive. 
## I have added more arrays and changed the structure of the program 